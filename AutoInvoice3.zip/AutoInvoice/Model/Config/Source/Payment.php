<?php

namespace Vdcstore\AutoInvoice\Model\Config\Source;

use \Magento\Framework\App\Config\ScopeConfigInterface;
use \Magento\Payment\Model\Config;

class Payment extends \Magento\Framework\DataObject
    implements \Magento\Framework\Option\ArrayInterface
{

    protected $_appConfigScopeConfigInterface;

    protected $paymentConfig;


    public function __construct(
        ScopeConfigInterface $appConfigScopeConfigInterface,
        Config               $paymentConfig
    )
    {
        $this->_appConfigScopeConfigInterface = $appConfigScopeConfigInterface;
        $this->paymentConfig = $paymentConfig;
    }

    public function toOptionArray()
    {
        $payments = $this->paymentConfig->getActiveMethods();
        $methods = array();
        foreach ($payments as $paymentCode => $paymentModel) {
            $paymentTitle = $this->_appConfigScopeConfigInterface
                ->getValue('payment/' . $paymentCode . '/title');
            $methods[$paymentCode] = array(
                'label' => $paymentTitle,
                'value' => $paymentCode
            );
        }
        return $methods;
    }
}
