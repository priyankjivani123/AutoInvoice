<?php

namespace Vdcstore\AutoInvoice\Block;

class Shipment extends \Magento\Framework\View\Element\Template
{
    protected $_invoiceCollectionFactory;

    protected $_invoiceRepository;

    protected $_invoiceService;

    protected $_transactionFactory;

    protected $_orderRepository;


    public function __construct(
        \Magento\Framework\View\Element\Template\Context                   $context,
        \Magento\Sales\Api\OrderRepositoryInterface                        $orderRepository,
        \Magento\Sales\Model\Convert\OrderFactory                          $convertOrderFactory,
        \Magento\Framework\DB\TransactionFactory                           $transactionFactory,
        \Magento\Sales\Model\Order\Email\Sender\ShipmentSender             $shipmentSender,
        \Magento\Framework\Message\ManagerInterface                        $messageManager,
        \Magento\Sales\Model\ResourceModel\Order\Invoice\CollectionFactory $invoiceCollectionFactory,
        \Magento\Sales\Model\Service\InvoiceService                        $invoiceService,
        \Magento\Sales\Api\InvoiceRepositoryInterface                      $invoiceRepository,
        array                                                              $data = []
    )
    {
        $this->orderRepository = $orderRepository;
        $this->orderConverter = $convertOrderFactory->create();
        $this->transactionFactory = $transactionFactory;
        $this->messageManager = $messageManager;
        $this->shipmentSender = $shipmentSender;
        $this->_invoiceCollectionFactory = $invoiceCollectionFactory;
        $this->_invoiceService = $invoiceService;
        $this->_transactionFactory = $transactionFactory;
        $this->_invoiceRepository = $invoiceRepository;
        $this->_orderRepository = $orderRepository;
        parent::__construct($context, $data);
    }

   
    public function generateShipment($orderId)
    {
        try {
            $order = $this->orderRepository->get($orderId);
            if (!$order->getId()) {
                throw new \Magento\Framework\Exception\LocalizedException(__('The order no longer exists.'));
            }

            if ($order->canShip()) {

                $shipment = $this->orderConverter->toShipment($order);
                foreach ($order->getAllItems() as $orderItem) {

                    if (!$orderItem->getQtyToShip() || $orderItem->getIsVirtual()) {
                        continue;
                    }
                    $qtyShipped = $orderItem->getQtyToShip();

                    $shipmentItem = $this->orderConverter->itemToShipmentItem($orderItem)->setQty($qtyShipped);

                    $shipment->addItem($shipmentItem);
                }

                $shipment->register();
                $shipment->getOrder()->setIsInProcess(true);
                try {
                    $transaction = $this->transactionFactory->create()->addObject($shipment)
                        ->addObject($shipment->getOrder())
                        ->save();
                    $shipmentId = $shipment->getIncrementId();
                } catch (\Exception $e) {
                    $this->messageManager->addError(__('We can\'t generate shipment.'));
                }
                if ($shipment) {
                    try {
                        $this->shipmentSender->send($shipment);
                    } catch (\Exception $e) {
                        $this->messageManager->addError(__('We can\'t send the shipment right now.'));
                    }
                }
                return $shipmentId;
            }
        } catch (\Exception $e) {
            $this->messageManager->addError($e->getMessage());
        }
        return true;
    }

    public function createInvoice($orderId)
    {
        try {
            $order = $this->_orderRepository->get($orderId);
            if ($order) {
                $invoices = $this->_invoiceCollectionFactory->create()
                    ->addAttributeToFilter('order_id', array('eq' => $order->getId()));

                $invoices->getSelect()->limit(1);

                if ((int)$invoices->count() !== 0) {
                    $invoices = $invoices->getFirstItem();
                    $invoice = $this->_invoiceRepository->get($invoices->getId());
                    return $invoice;
                }

                if (!$order->canInvoice()) {
                    return null;
                }

                $invoice = $this->_invoiceService->prepareInvoice($order);
                $invoice->setRequestedCaptureCase(\Magento\Sales\Model\Order\Invoice::CAPTURE_ONLINE);
                $invoice->register();
                $invoice->getOrder()->setCustomerNoteNotify(false);
                $invoice->getOrder()->setIsInProcess(true);
                $order->addStatusHistoryComment(__('Automatically Invoice'), false);
                $transactionSave = $this->_transactionFactory->create()->addObject($invoice)->addObject($invoice->getOrder());
                $transactionSave->save();

                return $invoice;
            }
        } catch (\Exception $e) {
            throw new \Magento\Framework\Exception\LocalizedException(
                __($e->getMessage())
            );
        }
    }

}
