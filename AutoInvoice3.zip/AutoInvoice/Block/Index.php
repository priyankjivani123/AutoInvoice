<?php

namespace Vdcstore\AutoInvoice\Block;

use Magento\Framework\View\Element\Template;
use Vdcstore\AutoInvoice\Helper\Data;
use Magento\Framework\View\Element\Template\Context;
use Magento\Framework\Serialize\SerializerInterface;

class Index extends Template
{
    protected $helperdata;


    public function __construct(
        \Magento\Catalog\Model\CategoryFactory $categoryFactory,
        Data                                   $helperdata,
        Context                                $context,
        array                                  $data = []
    )
    {

        parent::__construct($context, $data);
        $this->helperdata = $helperdata;
    }


    public function getEnabl()
    {
        return $this->helperdata->getGeneralConfig('enable');
    }

    public function getAutoInvoiceGeneration()
    {
        return $this->helperdata->getGeneralConfig('auto_invoice_generation');
    }

    public function getAutoShipmentGeneration()
    {
        return $this->helperdata->getGeneralConfig('auto_shipment_generation');
    }

    public function getSelectedPaaymentMethod()
    {
        return $this->helperdata->getGeneralConfig('payment_methodddd');
    }
   

}
