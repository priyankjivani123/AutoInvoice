<?php

namespace Vdcstore\AutoInvoice\Observer;

use Magento\Framework\Event\ObserverInterface;

class OrderObserver implements ObserverInterface
{
    public function __construct(
        \Vdcstore\AutoInvoice\Block\Shipment $BlockShipment,
        \Vdcstore\AutoInvoice\Block\Index    $IndexBlock,
        \Magento\Sales\Api\OrderRepositoryInterface $orderRepository,
        \Magento\Sales\Model\Order $order

    )
    {
        $this->BlockShipment = $BlockShipment;
        $this->IndexBlock = $IndexBlock;
        $this->orderRepository = $orderRepository;
        $this->order = $order;

    }


    public function execute(\Magento\Framework\Event\Observer $observer)
    { 
        $status = $this->IndexBlock->getEnabl();
        if($status=='1'){
        $orderId = $observer->getEvent()->getOrder()->getId();
        $getAutoInvoiceGeneration = $this->IndexBlock->getAutoInvoiceGeneration();
        $getAutoShipmentGeneration = $this->IndexBlock->getAutoShipmentGeneration();
        $getSelectedPaaymentMethod = $this->IndexBlock->getSelectedPaaymentMethod();
        $getSelectedPaaymentMethodArray = explode(",", $getSelectedPaaymentMethod);
        $order = $this->orderRepository->get($orderId);
        $orderIncrementId = $order->getIncrementId();
        $order = $this->order->loadByIncrementId($orderIncrementId);
        $payment =$order->getPayment();
        $method = $payment->getMethod();      

         if (in_array($method, $getSelectedPaaymentMethodArray)){
             if($getAutoInvoiceGeneration=='1')
             {
               $this->BlockShipment->createInvoice($orderId);
             }
             if($getAutoShipmentGeneration=='1')
             {
              $this->BlockShipment->generateShipment($orderId);

             }
                        
       }


       }                

    }

}
