<?php

namespace Vdcstore\AutoInvoice\Helper;

use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Store\Model\ScopeInterface;
use Magento\Customer\Model\Context;
use Magento\Framework\App\Area;
use Magento\Framework\App\Config\ScopeConfigInterface;

class Data extends AbstractHelper
{


    const XML_PATH_MINORDERAMT = 'autoinvoice/';

    public $scopeConfig;

    public $httpContext;

    public $productCache = [];

    public function __construct(
        ScopeConfigInterface                $scopeConfig,
        \Magento\Framework\App\Http\Context $httpContext
    )
    {
        $this->scopeConfig = $scopeConfig;
        $this->httpContext = $httpContext;
    }


    public function getConfigValue($field, $storeId = null)
    {
        return $this->scopeConfig->getValue(
            $field, ScopeInterface::SCOPE_STORE, $storeId
        );
    }

    public function getGeneralConfig($code, $storeId = null)
    {
        return $this->getConfigValue(self::XML_PATH_MINORDERAMT . 'general/' . $code, $storeId);
    }


}
